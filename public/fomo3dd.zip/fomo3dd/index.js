var express = require('express');
var app  = express();
app.use(express.static('./fomo3dd_2'));

app.listen(3080,()=>{
    console.log('listenning localhost:80')
})